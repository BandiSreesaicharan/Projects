from flask import Flask, render_template, request
import numpy as np
import pickle
from tensorflow.keras.models import load_model

# Load model and scaler
model = load_model("heart_wide_deep_model.h5")

with open("scaler.pkl", "rb") as f:
    scaler = pickle.load(f)

app = Flask(__name__)

# Feature list (must match training)
feature_cols = [
    "male", "age", "education", "currentSmoker", "cigsPerDay",
    "BPMeds", "prevalentStroke", "prevalentHyp", "diabetes",
    "totChol", "sysBP", "diaBP", "BMI", "heartRate", "glucose"
]

@app.route("/", methods=["GET", "POST"])
def index():
    prediction_text = ""

    if request.method == "POST":
        try:
            # Get input values
            values = [float(request.form[col]) for col in feature_cols]

            # Convert to array
            data = np.array([values])

            # Scale
            data_scaled = scaler.transform(data)

            # Predict
            prob = model.predict(data_scaled)[0][0]
            threshold = 0.35
            pred = 1 if prob >= threshold else 0

            if pred == 1:
                prediction_text = f"Heart Disease: YES (Probability = {prob:.3f})"
            else:
                prediction_text = f"Heart Disease: NO (Probability = {prob:.3f})"

        except Exception as e:
            prediction_text = f"Error: {str(e)}"

    return render_template("index.html", prediction=prediction_text, features=feature_cols)

if __name__ == "__main__":
    app.run(debug=True)
