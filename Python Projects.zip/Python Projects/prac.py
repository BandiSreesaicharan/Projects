a=[1,4,6,8,10,14,19,20,21,27,45,59,97,102]
l=0
u=len(a)-1

find=int(input("Enter Number: "))

i=0
while i < len(a):
    avg=int((l+u)/2)
    if a[avg] >  find :
        u=avg
    elif a[avg] < find:
        l=avg
    elif a[avg] == find:
        print("Found at position",avg)
        break
    else:
        print('Not Found')
        break
    i+=1