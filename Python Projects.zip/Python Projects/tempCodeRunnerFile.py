class subarray():
    def add(self,arr,target):
        for i in arr:
            sum=i
            for j in arr[i:]:
                sum=sum+j
                if sum == target :
                    return f'{arr.index(i)+1}, {arr.index(j)+1}'
        return -1

s1=subarray()
arr=list(map(int,input('Enter str : ').split()))
target=int(input("Target : "))
print(s1.add(arr,target))