class solution :
    def sort(self,arr) :
        arr.sort()
        return arr


arr = list(map(int, input("Enter Array 1: ").split()))
lenth=len(arr)
arr1 = list(map(int, input("Enter Array 2: ").split()))
arr+=arr1
solution().sort(arr)

print(" ".join(map(str,arr[:lenth])))
print(" ".join(map(str,arr[lenth:])))
